import 'package:flutter/material.dart';

import 'RegisterPage.dart'; //event registration

//pastevents

void main() {
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,

      initialRoute: '/RegisterPage',
      routes: {
        '/RegisterPage': (context) => RegisterPage(),
      }, //routes
    ), //materialapp
  ); //runapp
} //main
