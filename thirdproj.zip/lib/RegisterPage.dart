import 'package:flutter/material.dart';
//import 'Drawers/Draw1.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  //
  TextEditingController _name = TextEditingController();
  bool isNameValidate = false;

  TextEditingController _fathername = TextEditingController();
  bool isFatherNameValidate = false;

  TextEditingController _mail = TextEditingController();
  bool isMailValidate = false;

  TextEditingController _number = TextEditingController();
  bool isNumberValidate = false;

  TextEditingController _organization = TextEditingController();
  bool isOrganizationValidate = false;

  //

  bool validateTextFieldName(String userInput) {
    if (userInput.isEmpty) {
      setState(() {
        isNameValidate = true;
      });
      return false;
    }
    setState(() {
      isNameValidate = false;
    });
    return true;
  }

  bool validateTextFieldFatherName(String userInput) {
    if (userInput.isEmpty) {
      setState(() {
        isFatherNameValidate = true;
      });
      return false;
    }
    setState(() {
      isFatherNameValidate = false;
    });
    return true;
  }

  bool validateTextFieldMail(String userInput) {
    if (userInput.isEmpty) {
      setState(() {
        isMailValidate = true;
      });
      return false;
    }
    setState(() {
      isMailValidate = false;
    });
    return true;
  }

  bool validateTextFieldNumber(String userInput) {
    if (userInput.isEmpty) {
      setState(() {
        isNumberValidate = true;
      });
      return false;
    }
    setState(() {
      isNumberValidate = false;
    });
    return true;
  }

  bool validateTextFieldOrganization(String userInput) {
    if (userInput.isEmpty) {
      setState(() {
        isMailValidate = true;
      });
      return false;
    }
    setState(() {
      isOrganizationValidate = false;
    });
    return true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // drawer: Draw1(),
      backgroundColor: Colors.white,
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(250, 115, 92, 1),
        title: Text(
          'Event Registration',
          style: TextStyle(
            letterSpacing: 2.0,
            fontWeight: FontWeight.bold,
            color: Colors.white,
            fontFamily: 'Aleo',
          ), //ts
        ), //text
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [
                Color.fromRGBO(245, 148, 183, 1),
                Color.fromRGBO(173, 127, 251, 1),
                Color.fromRGBO(146, 178, 253, 1),
              ],
            ),
          ),
        ),
        centerTitle: true,
        elevation: 0,
      ), //appbar
      body: Stack(
        children: [
          Align(
            alignment: Alignment.center,
            child: ListView(
              children: [
                Image.asset(
                  'assets/register.png',
                  height: 170,
                ), //children
                SizedBox(
                  height: 6,
                ),
                //email ka container
                Padding(
                  padding: EdgeInsets.only(left: 12, right: 12, top: 5),
                  child: Container(
                    height: 55,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Color.fromRGBO(146, 178, 253, 1),
                          Color.fromRGBO(245, 148, 183, 1),
                          Color.fromRGBO(173, 127, 251, 1),
                        ],
                      ),
                    ),
                    child: TextField(
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.sentences,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontFamily: 'Aleo',
                      ), //ye input color sa associated
                      decoration: InputDecoration(
                        icon: Icon(
                          Icons.email,
                          color: Colors.white,
                        ),

                        border: InputBorder.none,
                        hintText: 'Email *',
                        enabledBorder: OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0),
                          borderSide: BorderSide(color: Colors.white),
                        ),

                        hintStyle: TextStyle(
                          fontSize: 15.0,
                          color: Colors.white,
                          fontFamily: 'Aleo',
                          letterSpacing: 3,
                        ), //ye hint ka color sa
                      ),
                      controller: _mail,
                    ),
                  ), //emial ka container
                ),
                //children2
//name ka container
                Padding(
                  padding: EdgeInsets.only(left: 12, right: 12, top: 5),
                  child: Container(
                    height: 55,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Color.fromRGBO(245, 148, 183, 1),
                          Color.fromRGBO(173, 127, 251, 1),
                          Color.fromRGBO(146, 178, 253, 1),
                        ],
                      ),
                    ),
                    child: TextField(
                      textAlign: TextAlign.center,
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.sentences,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontFamily: 'Aleo',
                      ), //ye input color sa associated

                      decoration: InputDecoration(
                        icon: Icon(
                          Icons.person,
                          color: Colors.white,
                        ),
                        hintText: 'Name *',

                        enabledBorder: OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0),
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        border: InputBorder.none,

                        hintStyle: TextStyle(
                          fontSize: 15.0,
                          color: Colors.white,
                          fontFamily: 'Aleo',
                          letterSpacing: 3,
                        ), //ye hint ka color sa
                      ),
                      controller: _name,
                    ),
                  ),
                ), //name ka container

                //father name
                Padding(
                  padding: EdgeInsets.only(left: 12, right: 12, top: 5),
                  child: Container(
                    height: 55,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Color.fromRGBO(146, 178, 253, 1),
                          Color.fromRGBO(245, 148, 183, 1),
                          Color.fromRGBO(173, 127, 251, 1),
                        ],
                      ),
                    ),
                    child: TextField(
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.sentences,
                      textAlign: TextAlign.center,

                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontFamily: 'Aleo',
                      ), //ye input color sa associated
                      decoration: InputDecoration(
                        icon: Icon(
                          Icons.people,
                          color: Colors.white,
                        ),
                        border: InputBorder.none,
                        hintText: 'Father Name *',
                        enabledBorder: OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0),
                          borderSide: BorderSide(color: Colors.white),
                        ),

                        hintStyle: TextStyle(
                          fontSize: 15.0,
                          color: Colors.white,
                          fontFamily: 'Aleo',
                          letterSpacing: 3,
                        ), //ye hint ka color sa
                      ),
                      controller: _fathername,
                    ),
                  ), //emial ka container
                ),
                //father name

                //phone ka container
                Padding(
                  padding: EdgeInsets.only(left: 12, right: 12, top: 5),
                  child: Container(
                    height: 55,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Color.fromRGBO(173, 127, 251, 1),
                          Color.fromRGBO(245, 148, 183, 1),
                          Color.fromRGBO(146, 178, 253, 1),
                        ],
                      ),
                    ),
                    child: TextField(
                      keyboardType: TextInputType.number,

                      textAlign: TextAlign.center,

                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontFamily: 'Aleo',
                      ), //ye input color sa associated
                      decoration: InputDecoration(
                        icon: Icon(
                          Icons.phone,
                          color: Colors.white,
                        ),
                        hintText: 'Phone *',

                        enabledBorder: OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0),
                          borderSide: BorderSide(color: Colors.white),
                        ),
                        border: InputBorder.none,
                        hintStyle: TextStyle(
                          fontSize: 15.0,
                          color: Colors.white,
                          fontFamily: 'Aleo',
                          letterSpacing: 3,
                        ), //ye hint ka color sa
                      ),
                      controller: _number,
                    ),
                  ),
                ), //phone ka container

//organizatio
                Padding(
                  padding: EdgeInsets.only(left: 12, right: 12, top: 5),
                  child: Container(
                    height: 55,
                    padding: EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      gradient: LinearGradient(
                        begin: Alignment.topRight,
                        end: Alignment.bottomLeft,
                        colors: [
                          Color.fromRGBO(146, 178, 253, 1),
                          Color.fromRGBO(245, 148, 183, 1),
                          Color.fromRGBO(173, 127, 251, 1),
                        ],
                      ),
                    ),
                    child: TextField(
                      keyboardType: TextInputType.text,
                      textCapitalization: TextCapitalization.sentences,
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 18.0,
                        fontFamily: 'Aleo',
                      ), //ye input color sa associated
                      decoration: InputDecoration(
                        icon: Icon(
                          Icons.account_balance,
                          color: Colors.white,
                        ),
                        hintText: 'Organization',
                        enabledBorder: OutlineInputBorder(
                          borderRadius: new BorderRadius.circular(20.0),
                          borderSide: BorderSide(color: Colors.white),
                        ),

                        border: InputBorder.none,
                        hintStyle: TextStyle(
                          fontSize: 15.0,
                          color: Colors.white,
                          fontFamily: 'Aleo',
                          letterSpacing: 3,
                        ), //ye hint ka color sa
                      ),
                      controller: _organization,
                    ),
                  ),
                ), //organization ka container

                Padding(
                  padding: EdgeInsets.only(left: 70, right: 70, top: 5),
                  child: InkWell(
                    onTap: () {
                      if (validateTextFieldMail(_mail.text) == true) {
                        if (validateTextFieldName(_name.text) == true) {
                          if (validateTextFieldFatherName(_fathername.text) == true) {
                            if (validateTextFieldNumber(_number.text) == true) {
                              //            Navigator.pushNamed(context, '/submit');
                              _mail.clear();
                              _name.clear();
                              _fathername.clear();
                              _number.clear();
                              _organization.clear();
                            }
                          }
                        }
                      }
                    },
                    //
                    child: Container(
                      height: 35,
                      width: 30,

                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          colors: [
                            Color.fromRGBO(245, 148, 183, 1),
                            Color.fromRGBO(173, 127, 251, 1),
                            Color.fromRGBO(146, 178, 253, 1),
                          ],
                        ),
                      ), //box deco

                      padding: EdgeInsets.symmetric(
                        vertical: 10,
                      ), //padding

                      alignment: Alignment.center,
                      child: Text(
                        'submit',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.white,
                          fontFamily: 'Aleo',
                          letterSpacing: 3,
                        ),
                      ),
                    ), //cont
                  ),
                ), //inkwell
                SizedBox(
                  height: 5.0,
                ),
                Container(
                  child: Text(
                    "Note: * field are mandatory else form wont be submitted",
                    style: TextStyle(
                      fontSize: 16.5,
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Aleo',
                      letterSpacing: 1.5,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(
                  height: 25.0,
                ),
              ],
            ), //listview
          ), //allign:
        ], //children
      ), //stack
    );
  }
}
